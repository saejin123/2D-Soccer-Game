﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerController : MonoBehaviour {
	public float speed = 7;
	public event System.Action OnPlayerDeath;
	public float screenhalfwidth;
	// Use this for initialization
	void Start () {
		float halfplayerwidth = transform.localScale.x/2f;
		screenhalfwidth = Camera.main.aspect*Camera.main.orthographicSize+halfplayerwidth; // orthographicsize is screen height/2
	}
	 
	// Update is called once per frame
	void Update () {
		float inputX = Input.GetAxisRaw("Horizontal");
		float velocity = inputX*speed;
		transform.Translate(Vector2.right*velocity*Time.deltaTime); // this is how you move a player
		if(transform.position.x < -screenhalfwidth){ // this is bad bc if you change the size of the game camera you would always have to update this -> very inefficent -> can do this now since the variable is set to the main camera's settings
			transform.position = new Vector2(screenhalfwidth, transform.position.y);
		}
		if(transform.position.x > screenhalfwidth){
			transform.position = new Vector2(-screenhalfwidth, transform.position.y);
		}

	}
	void OnTriggerEnter2D(Collider2D triggerCollider){ // called automatically by the 2d physics engine
		if(triggerCollider.tag == "Falling Block"){
			// FindObjectOfType<GameOver> ().onGameOver(); // kinda strange to have this here so the soln is an event
			if(OnPlayerDeath != null){
				OnPlayerDeath();
			}
			Destroy (gameObject);
		}
	}
}
